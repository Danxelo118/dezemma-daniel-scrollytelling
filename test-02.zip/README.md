# Projet Scrollytelling: Paper Plane

## Projet scolaire dans le cadre du cours Optimisation Web - Projet Scrollytelling

## Conception

- Matis Labelle
- Daniel Dezemma

## Développement/programmation

- Daniel Dezemma

## Technologies

- HTML
- CSS
- Javascript
- [Librairie d'animation GSAP](https://gsap.com/).
- [Plugiciel ScrollTrigger](https://gsap.com/docs/v3/Plugins/ScrollTrigger/).
